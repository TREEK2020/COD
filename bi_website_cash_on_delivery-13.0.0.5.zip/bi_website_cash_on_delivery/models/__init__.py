# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import cash_on_delivery
from . import cod_product
from . import cod_payment

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

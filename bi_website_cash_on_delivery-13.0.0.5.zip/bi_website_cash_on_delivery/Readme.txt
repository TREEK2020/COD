
=> 13.0.0.1 : Improved related, demanded apps link or add live test url link.

=> 13.0.0.2 : Improved compute of Product delivery fees.

=> 13.0.0.3 : Changed Cash On Delivery checking to allow on basis of Country and State/Zip.

=> 13.0.0.4 : Solved Public User issue for COD on website shop.

=> 13.0.0.5 : Solved odoobot issue on public user signup.